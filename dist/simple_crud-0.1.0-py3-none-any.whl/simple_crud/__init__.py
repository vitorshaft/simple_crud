# Importa a classe Database diretamente do módulo simple_crud.py
from .simple_crud import Database

# Define o que será exposto quando o pacote for importado
__all__ = ["Database"]